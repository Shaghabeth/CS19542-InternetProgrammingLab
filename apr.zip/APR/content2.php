	<div class="testimonial">	
					<div class="caption_index_2">TESTIMONIAL</div>
					<div class="testimonial_div">
					<p>
					I was delighted with the treatment. Despite me being a somewhat difficult patient Dr. Terry Lee was really gentle, patient and understanding.
					The treatment was explained precisely to me and the price was quoted right at the beginning which is exactly what the price was at the end.
					The transformation to my teeth and to my life in general has been amazing. 
					I know have a smile that I’m not afraid to show anymore. I am extremely happy with the quality of the treatment.
					</p>
					</div>
					<div class="testimonial_div1">
						<p>
	Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam cursus. Morbi ut mi. Nullam enim leo, egestas id, condimentum at, laoreet mattis, massa. Sed eleifend nonummy diam. Praesent mauris ante, elementum et, bibendum at, posuere sit amet, nibh. Duis tincidunt lectus quis dui viverra vestibulum. Suspendisse vulputate aliquam dui. Nulla elementum dui ut augue. Aliquam vehicula mi at mauris. Maecenas placerat, nisl at consequat rhoncus, sem nunc gravida justo, quis eleifend arcu velit quis lacus. Morbi magna magna, tincidunt a, mattis non, imperdiet vitae, tellus. Sed odio est, auctor ac, sollicitudin in, consequat vitae, orci. Fusce id felis. Vivamus sollicitudin metus eget eros.
					</p>
					</div>
					</div>
					<div class="contact_us">
						<div class="caption_index_2">VISIT OUR OFFICE</div>	
						<p>Office Hours</p>
						<p>Monday - Thursday (8:00 am to 5:00 pm)</p>
						<p>Monday - Thursday (8:00 am to 5:00 pm)</p>
						<p>Room 312</p>
						<p>Dr. Pablo O Torre Memorial Hospital B.S Aquino Drive</p>
						<p>Bacolod City Negros Occidental</p>
					</div>
					<div class="site_map">
					<iframe width="300" height="300" frameborder="10" scrolling="no" marginheight="0" marginwidth="auto"
                           src="http://maps.google.com/maps/ms?doflg=ptm&amp;ie=UTF8&amp;msa=0&amp;msid=203722259750162261795.0004aafd513ccced356f4&amp;sll=10.743085,122.969515&amp;sspn=0,0&amp;ll=10.743346,122.969686&amp;spn=0,0&amp;t=h&amp;vpsrc=0&amp;output=embed">
                    </iframe>
					</div>