<div class="container">   
   <footer class="footer">
      <div class="container">
	  <div class="foot-margin">
        <p><a>Copyright � 2013 Reverside Medical Hospital. All Rightsreserved</a></p>
      </div>
      </div>
    </footer>
</div>
</body>
</html>